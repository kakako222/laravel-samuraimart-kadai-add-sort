<!DOCTYPE html>
 <html lang="ja">
 
 <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>投稿一覧</title>
 </head>
 
 <body>
     <header>
         <nav> 
             <a href="<?php echo e(route('posts.index')); ?>">投稿アプリ</a>
 
             <ul>
                 <li> 
                     <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">ログアウト</a>
                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                         <?php echo csrf_field(); ?>
                     </form>
                 </li>
             </ul>
         </nav>
     </header>
 
     <main>
         <h1>投稿一覧</h1>
 
         <?php if($posts->isNotEmpty()): ?>
             <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <article>
                     <h2><?php echo e($post->title); ?></h2>
                     <p><?php echo e($post->content); ?></p>
                     <a href="<?php echo e(route('posts.show', $post)); ?>">詳細</a>
                 </article>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php else: ?>
             <p>投稿はありません。</p>
         <?php endif; ?>
     </main>
 
     <footer>
         <p>&copy; 投稿アプリ All rights reserved.</p>
     </footer>
 </body>
 
 </html><?php /**PATH /Applications/MAMP/htdocs/laravel-posting-app/resources/views/posts/index.blade.php ENDPATH**/ ?>